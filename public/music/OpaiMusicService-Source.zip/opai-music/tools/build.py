#!/usr/bin/env python3
"""Build the local Java music service and include complete corresponding source."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--gson',type=Path);args=parser.parse_args()
gsons=sorted((Path.home()/'.gradle/caches/modules-2/files-2.1/com.google.code.gson/gson').glob('2.11.0/*/*.jar'))
gson=args.gson or next(iter(gsons),None)
assert gson, 'The supplied client Gson dependency is required to compile.'
classes=root/'build/classes';classes.mkdir(parents=True,exist_ok=True)
subprocess.run(['javac','--release','21','-encoding','UTF-8','-cp',str(gson),'-d',str(classes),*[str(p) for p in sorted((root/'src').rglob('*.java'))]],check=True)
out=root.parent/'opai-theme/public/music';out.mkdir(parents=True,exist_ok=True)
jar=out/'OpaiMusicService.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(classes.rglob('*.class')):
        if 'Test' not in p.name:z.write(p,p.relative_to(classes).as_posix())
    z.write(root/'LICENSE-TRITIUM','LICENSE-TRITIUM');z.write(root/'UPSTREAM.md','UPSTREAM.md');z.write(root/'LICENSE-DANGO','LICENSE-DANGO')
source=out/'OpaiMusicService-Source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and not any(part in {'build','.git','__pycache__'} for part in p.relative_to(root).parts):z.write(p,'opai-music/'+p.relative_to(root).as_posix())
for name in ['LICENSE-TRITIUM','LICENSE-DANGO','UPSTREAM.md']:shutil.copyfile(root/name,out/name)
report={'service_version':'1.2.0','java_release':21,'jar_bytes':jar.stat().st_size,'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_files':len(list((root/'src').rglob('*.java')))}
(root/'build/package.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
