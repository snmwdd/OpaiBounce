# Opai Music local service 1.2.0

Java implementation used by theme 1.12.0 and bridge script 1.4.0. It provides the Tritium Music NetEase QR protocol, search and account playlists, GD音乐台 requests, rate limiting, native playback, volume and repeat-one.

The native player is adapted from [Tritium Music](https://github.com/opai-client/tritium-music), GPL-3.0; the vendored MP3/FLAC decoders retain their own notices. Complete corresponding sources are distributed as `OpaiMusicService-Source.zip`. QR encoding in the theme uses node-qrcode, MIT.

GD attribution: **GD音乐台 (music.gdstudio.xyz)**. API use is for non-commercial study under the provider's stated CC BY-NC 4.0 terms. No music recordings are included, downloaded to disk or exported by the player. Streams are decoded in memory. The test fixtures are self-generated digital silence.

Supported audio: MP3, FLAC and Java Sound PCM/WAV. Some GD sources return AAC/M4A streams; these produce an explicit format message, and the user can select the NetEase source. Playback availability is determined by each provider and, in official mode, by the logged-in account.

The service is loaded from the theme by OpaiBridge. It binds only a random 127.0.0.1 port, authenticates requests with a random per-run token and keeps the official Cookie in `LiquidBounce/opai-music/settings.json`. The UI never receives it, and GD requests do not carry it. Settings are written atomically; volume, repeat mode, provider and official session survive restarts. Closing the music UI does not stop playback; unloading the script does.

Build with JDK 21 or later and Gson 2.11+:

```sh
python3 tools/build.py --gson /absolute/path/to/gson-2.11.0.jar
```

The helper targets Java 21 bytecode; the current Minecraft 26.3 client itself still requires Java 25+. Run `tests/MusicServiceTest.java` with Gson on the classpath for local protocol/state/cache/quota tests, and `tests/NativeAudioTest.java` for silent MP3/FLAC output-device tests. No real account credentials are used by tests.

1.1.0 adds independently persisted music HUD switches, atomic local favorites (not cloud favorites), and 32 logarithmic spectrum bands computed from the actual decoded PCM. Spectrum samples are taken before the volume fader; paused/stale output returns silence.

1.2.0 adds configureModule/openPlayer/worldLyrics/clearWorldLyrics for the registered script module, Dango world lyric scenes, YRC data and native end-of-playback state cleanup. Rendering is in the Bridge WorldFeatureSubmitEvent handler; no Minecraft classes are needed to compile this service.
