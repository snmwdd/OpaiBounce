/*
 * Created on Jun 28, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package repackage.org.kc7bfi.jflac;

import repackage.org.kc7bfi.jflac.metadata.StreamInfo;
import repackage.org.kc7bfi.jflac.util.ByteData;

import java.util.HashSet;


/**
 * Class to handle PCM processors.
 *
 * @author kc7bfi
 */
class PCMProcessors implements PCMProcessor {
    private final HashSet pcmProcessors = new HashSet();

    /**
     * Add a PCM processor.
     *
     * @param processor The processor listener to add
     */
    public void addPCMProcessor(PCMProcessor processor) {
        synchronized (pcmProcessors) {
            pcmProcessors.add(processor);
        }
    }

    /**
     * Remove a PCM processor.
     *
     * @param processor The processor listener to remove
     */
    public void removePCMProcessor(PCMProcessor processor) {
        synchronized (pcmProcessors) {
            pcmProcessors.remove(processor);
        }
    }

    /**
     * Process the StreamInfo block.
     *
     * @param info the StreamInfo block
     * @see PCMProcessor#processStreamInfo(StreamInfo)
     */
    public void processStreamInfo(StreamInfo info) {
        synchronized (pcmProcessors) {
            for (Object pcmProcessor : pcmProcessors) {
                PCMProcessor processor = (PCMProcessor) pcmProcessor;
                processor.processStreamInfo(info);
            }
        }
    }

    /**
     * Process the decoded PCM bytes.
     *
     * @param pcm The decoded PCM data
     * @see PCMProcessor#processPCM(org.kc7bfi.jflac.util.ByteSpace)
     */
    public void processPCM(ByteData pcm) {
        synchronized (pcmProcessors) {
            for (Object pcmProcessor : pcmProcessors) {
                PCMProcessor processor = (PCMProcessor) pcmProcessor;
                processor.processPCM(pcm);
            }
        }
    }

    public boolean isCanceled() {
        return pcmProcessors.isEmpty();
    }

}
